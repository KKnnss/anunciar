import { Component } from '@angular/core';

@Component({
  selector: 'pro-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent {

}
