import { Component } from '@angular/core';

@Component({
  selector: 'pro-anunciar-evento',
  templateUrl: './anunciar-evento.component.html',
  styleUrls: ['./anunciar-evento.component.css']
})
export class AnunciarEventoComponent {

}
